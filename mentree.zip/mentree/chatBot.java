package com.example.mentree;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.java.GenerativeModelFutures;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerateContentResponse;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class chatBot extends AppCompatActivity {
    RecyclerView recyclerView;
    TextView welcomeTextView;
    EditText messageEditText;
    ImageButton sendButton;
    List<Message> messageList;
    MessageAdapter messageAdapter;

    Executor executor = Executors.newSingleThreadExecutor();
    String userName;
    String conversationHistory = "";
    GenerativeModel gm = new GenerativeModel("gemini-1.5-flash", "AIzaSyBqi1j8HCQKajX3tN48AuPuB5e8FY-s4qg");
    GenerativeModelFutures model = GenerativeModelFutures.from(gm);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_bot);

        recyclerView = findViewById(R.id.recycler_view);
        welcomeTextView = findViewById(R.id.welcome_text);
        messageEditText = findViewById(R.id.message_edit_text);
        sendButton = findViewById(R.id.send_btn);

        messageList = new ArrayList<>();
        messageAdapter = new MessageAdapter(messageList);
        recyclerView.setAdapter(messageAdapter);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setStackFromEnd(true);
        recyclerView.setLayoutManager(llm);

        // Load saved user name and conversation history
        userName = getUserName();
        conversationHistory = getConversationHistory();
        welcomeTextView.setText("Welcome back, " + userName + "!");

        sendButton.setOnClickListener(v -> {
            String question = messageEditText.getText().toString().trim();
            if (!question.isEmpty()) {
                addToChat(question, Message.SENT_BY_ME);
                messageEditText.setText("");
                callGeminiAPI(question);
                welcomeTextView.setVisibility(View.GONE);
            }
        });
    }

    // Save user's name in SharedPreferences
    public void saveUserName(String name) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("user_name", name);  // Store the name
        editor.apply();
    }

    // Get the user's name from SharedPreferences
    public String getUserName() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        return sharedPreferences.getString("user_name", "User");  // Default is "User"
    }

    // Save conversation history
    public void saveConversationHistory(String conversation) {
        SharedPreferences sharedPreferences = getSharedPreferences("ConversationPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("conversation_history", conversation);  // Store conversation
        editor.apply();
    }

    // Retrieve conversation history from SharedPreferences
    public String getConversationHistory() {
        SharedPreferences sharedPreferences = getSharedPreferences("ConversationPrefs", MODE_PRIVATE);
        return sharedPreferences.getString("conversation_history", "");  // Default is empty
    }

    // Call the Gemini API and send the conversation history as context
    void callGeminiAPI(String question) {
        // Add the new question to the conversation history
        String fullContext = conversationHistory + "\nUser: " + question;

        Content content = new Content.Builder().addText(fullContext).build();

        ListenableFuture<GenerateContentResponse> response = model.generateContent(content);
        Futures.addCallback(response, new FutureCallback<GenerateContentResponse>() {
            @Override
            public void onSuccess(GenerateContentResponse result) {
                String resultText = result.getText();
                addResponse(resultText);

                // Update the conversation history with the response from the bot
                conversationHistory += "\nBot: " + resultText;
                saveConversationHistory(conversationHistory);  // Save the updated conversation
            }

            @Override
            public void onFailure(Throwable t) {
                t.printStackTrace();
                addResponse("Failed to load response due to an internal error");
            }
        }, executor);
    }

    // Update the chat with the user's message
    void addToChat(String message, String sentBy) {
        runOnUiThread(() -> {
            messageList.add(new Message(message, sentBy));
            messageAdapter.notifyItemInserted(messageList.size() - 1);
            recyclerView.smoothScrollToPosition(messageList.size() - 1);
        });
    }

    // Update the chat with the bot's response
    void addResponse(String response) {
        runOnUiThread(() -> addToChat(response, Message.SENT_BY_BOT));
    }
}
