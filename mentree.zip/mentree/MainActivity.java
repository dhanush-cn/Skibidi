package com.example.mentree;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText nameEditText;
    private EditText dobEditText;
    private RadioGroup genderRadioGroup;
    private ImageButton imageButton;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        boolean isFirstTime = sharedPreferences.getBoolean("isFirstTime", true);

        if (isFirstTime) {
            setContentView(R.layout.activity_main);

            nameEditText = findViewById(R.id.editText_name);
            dobEditText = findViewById(R.id.editText_age);
            genderRadioGroup = findViewById(R.id.radioGroup);
            imageButton = findViewById(R.id.bottom_bar);

            imageButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openProfileActivity();
                }
            });

            dobEditText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showDatePickerDialog();
                }
            });

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("isFirstTime", false);
            editor.apply();
        } else {
            Intent intent = new Intent(this, homeScreen.class);
            startActivity(intent);
            finish();
        }
    }

    @SuppressLint("NonConstantResourceId")
    private void openProfileActivity() {
        RadioGroup acceptRejectRadioGroup = findViewById(R.id.acceptRejectRadioGroup);
        int selectedOptionId = acceptRejectRadioGroup.getCheckedRadioButtonId();

        if (selectedOptionId == -1) {
            Toast.makeText(this, "Please accept the terms and conditions to continue", Toast.LENGTH_SHORT).show();
            return;
        }

        String name = nameEditText.getText().toString().trim();
        String dob = dobEditText.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(dob)) {
            Toast.makeText(this, "Please enter your date of birth", Toast.LENGTH_SHORT).show();
            return;
        }

        int selectedGenderId = genderRadioGroup.getCheckedRadioButtonId();
        String gender1 = "";
        if (selectedGenderId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedGenderId);
            if (selectedRadioButton != null) {
                gender1 = selectedRadioButton.getText().toString();
            }
        }

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioButton selectedRadioButton = findViewById(selectedGenderId);
                String name = nameEditText.getText().toString();
                String dob = dobEditText.getText().toString();
                String gender = selectedRadioButton.getText().toString();

                Intent intent = new Intent(MainActivity.this, profile.class);
                intent.putExtra("keyname",name);
                intent.putExtra("keydob",dob);
                intent.putExtra("keygender",gender);
                startActivity(intent);
            }
        });


    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        calendar.set(year, month, dayOfMonth);
                        dobEditText.setText(dateFormat.format(calendar.getTime()));
                    }
                }, year, month, dayOfMonth);

        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }
}
