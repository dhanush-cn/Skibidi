package com.example.mentree;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class hummingBee extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_humming_bee);
        VideoView videoView = findViewById(R.id.vv);

        // Set the path or URI of your video file
        String videoPath = "android.resource://" + getPackageName() + "/" + R.raw.cycle;

        // Set the URI of the video to the VideoView
        videoView.setVideoURI(Uri.parse(videoPath));

        // Create a MediaController to control playback (optional)
        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(videoView);
        videoView.setMediaController(mediaController);

        // Start playing the video
        videoView.start();

        // Loop the video
        videoView.setOnCompletionListener(mp -> {
            // Restart video when completed
            videoView.start();
        });
    }
}
