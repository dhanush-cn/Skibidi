package com.example.mentree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class profile extends AppCompatActivity {
    private TextView textViewName;
    private TextView textViewDOB;
    private TextView textViewGender;
    private ImageButton button61;
    private ImageButton button62;
    private ImageButton button63;
    private ImageButton button64;
    private ImageButton button65;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Initialize views
        textViewName = findViewById(R.id.textView_name);
        textViewDOB = findViewById(R.id.textView_dob);
        textViewGender = findViewById(R.id.textView_gender);
        button61 = findViewById(R.id.button61);
        button62 = findViewById(R.id.button62);
        button63 = findViewById(R.id.button63);
        button64 = findViewById(R.id.button64);
        button65 = findViewById(R.id.button65);

        // Set button click listeners (assuming you already have them implemented)

        // Retrieve extras from the intent
        String name = getIntent().getStringExtra("keyname");
        String dob = getIntent().getStringExtra("keydob");
        String gender = getIntent().getStringExtra("keygender");

        // Set retrieved data to TextViews
        textViewName.setText(name);
        textViewDOB.setText(dob);
        textViewGender.setText(gender);

        button61.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(profile.this, homeScreen.class));
            }
        });
        button62.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(profile.this, meditation.class));
            }
        });

        button63.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(profile.this, chatBot.class));
            }
        });

        button64.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(profile.this, community.class));
            }
        });

        button65.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(profile.this, more.class));
            }
        });
    }
}
