package com.example.mentree;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;

public class meditation extends AppCompatActivity {

    private VideoView videoView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meditation);
        ImageButton button21 = findViewById(R.id.button21);
        ImageButton button23 = findViewById(R.id.button23);
        ImageButton button24 = findViewById(R.id.button24);
        ImageButton button25 = findViewById(R.id.button25);
        ImageButton button26 = findViewById(R.id.button26);
        ImageButton B1 = findViewById(R.id.B1);
        ImageButton B2 = findViewById(R.id.B2);
        ImageButton B3 = findViewById(R.id.B3);
        ImageButton B4 = findViewById(R.id.B4);
        ImageButton B5 = findViewById(R.id.B5);

        button21.setOnClickListener(v -> startActivity(new Intent(meditation.this, homeScreen.class)));
        button23.setOnClickListener(v -> startActivity(new Intent(meditation.this, chatBot.class)));
        button24.setOnClickListener(v -> startActivity(new Intent(meditation.this, community.class)));
        button25.setOnClickListener(v -> startActivity(new Intent(meditation.this, more.class)));
        button26.setOnClickListener(v -> startActivity(new Intent(meditation.this, profile.class)));
        B1.setOnClickListener(v -> startActivity(new Intent(meditation.this,deepBreath.class)));
        B2.setOnClickListener(v -> startActivity(new Intent(meditation.this,main555rule.class)));
        B3.setOnClickListener(v -> startActivity(new Intent(meditation.this,hummingBee.class)));
        B4.setOnClickListener(v -> startActivity(new Intent(meditation.this,cyclicBreathing.class)));
        B5.setOnClickListener(v -> startActivity(new Intent(meditation.this,boxBreathing.class)));


    }
}
