package com.example.mentree;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.PopupWindow;


public class community extends AppCompatActivity {

    private PopupWindow popupWindow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community); // Use community layout

        ImageButton button41 = findViewById(R.id.button41);
        ImageButton button42 = findViewById(R.id.button42);
        ImageButton button43 = findViewById(R.id.button43);
        ImageButton button45 = findViewById(R.id.button45);
        ImageButton button46 = findViewById(R.id.button46);

        // Set onClickListener for buttons
        button42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(community.this, meditation.class));
            }
        });

        button43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(community.this, chatBot.class));
            }
        });

        button41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(community.this, homeScreen.class));
            }
        });

        button45.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(community.this, more.class));
            }
        });

        button46.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(community.this, profile.class));
            }
        });

        setPopupWindow(findViewById(R.id.lesson1_popup), R.layout.lesson1_popup);
        setPopupWindow(findViewById(R.id.lesson2_popup), R.layout.lesson2_popup);
        setPopupWindow(findViewById(R.id.lesson3_popup), R.layout.lesson3_popup);
        setPopupWindow(findViewById(R.id.lesson4_popup), R.layout.lesson4_popup);
        setPopupWindow(findViewById(R.id.lesson5_popup), R.layout.lesson5_popup);
    }

    private void setPopupWindow(final ImageButton button, final int layoutId) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the current popup window if it is showing
                dismissPopupWindow();

                // Show the new layout as a popup widget
                showPopupWindow(button, layoutId);
            }
        });
    }

    private void showPopupWindow(View anchorView, int layoutId) {
        View popupView = LayoutInflater.from(this).inflate(layoutId, null);

        popupWindow = new PopupWindow(
                popupView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        // Set focusable and touchable to true
        popupWindow.setFocusable(true);
        popupWindow.setTouchable(true);

        // Calculate the pixel value for 100dp margin
        int marginInPixels = dpToPixels(100);

        // Set the position of the PopupWindow with a 100dp margin from the top of the screen
        popupWindow.showAtLocation(anchorView, Gravity.TOP, 0, marginInPixels);

        // Dismiss the popup window when touched outside or when back button is pressed
        popupView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
                    dismissPopupWindow();
                    return true;
                }
                return false;
            }
        });
    }

    private void dismissPopupWindow() {
        if (popupWindow != null && popupWindow.isShowing()) {
            popupWindow.dismiss();
        }
    }

    // Helper method to convert dp to pixels
    private int dpToPixels(int dp) {
        Context context = getApplicationContext();
        float density = context.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
