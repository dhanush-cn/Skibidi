package com.example.mentree;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class homeScreen extends AppCompatActivity implements SensorEventListener {
    private SensorManager mSensorManager=null;
    private Sensor stepSensor;
    private int totalSteps = 0;
    private int previousTotalSteps = 0;
    private ProgressBar progressBar;
    private TextView steps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        progressBar=findViewById(R.id.progressBar);
        steps=findViewById(R.id.steps);

        resetSteps();
        setupButtons();
        loadData();
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        stepSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);


    }

    private void setupButtons() {
        ImageButton button2 = findViewById(R.id.button2);
        ImageButton button3 = findViewById(R.id.button3);
        ImageButton button4 = findViewById(R.id.button4);
        ImageButton button5 = findViewById(R.id.button5);
        ImageButton button6 = findViewById(R.id.button6);
        ImageButton go = findViewById(R.id.go);
        ImageButton angryButton = findViewById(R.id.angry);
        ImageButton sadButton = findViewById(R.id.sad);
        ImageButton lovedButton = findViewById(R.id.loved);
        ImageButton happyButton = findViewById(R.id.happy);
        ImageButton lazyButton = findViewById(R.id.lazy);
        ImageButton motivatedButton = findViewById(R.id.motivated);

        angryButton.setOnClickListener(v -> showPopup(v, R.layout.angry_popup));
        sadButton.setOnClickListener(v -> showPopup(v, R.layout.sad_popup));
        lovedButton.setOnClickListener(v -> showPopup(v, R.layout.loved_popup));
        happyButton.setOnClickListener(v -> showPopup(v, R.layout.happy_popup));
        lazyButton.setOnClickListener(v -> showPopup(v, R.layout.lazy_popup));
        motivatedButton.setOnClickListener(v -> showPopup(v, R.layout.motivated_poppup));

        button2.setOnClickListener(v -> startActivity(new Intent(homeScreen.this, meditation.class)));
        button3.setOnClickListener(v -> startActivity(new Intent(homeScreen.this, chatBot.class)));
        go.setOnClickListener(v -> startActivity(new Intent(homeScreen.this, chatBot.class)));
        button4.setOnClickListener(v -> startActivity(new Intent(homeScreen.this, community.class)));
        button5.setOnClickListener(v -> startActivity(new Intent(homeScreen.this, more.class)));
        button6.setOnClickListener(v -> startActivity(new Intent(homeScreen.this, profile.class)));
    }

    private void showPopup(View anchorView, int popupLayoutId) {
        View popupView = LayoutInflater.from(this).inflate(popupLayoutId, null);
        PopupWindow popupWindow = new PopupWindow(popupView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        popupWindow.setFocusable(true);

        int[] location = new int[2];
        anchorView.getLocationOnScreen(location);
        int anchorX = location[0];
        int anchorY = location[1];
        int anchorWidth = anchorView.getWidth();
        int anchorHeight = anchorView.getHeight();
        int popupWidth = popupWindow.getWidth();
        int popupHeight = popupWindow.getHeight();
        int x = anchorX + (anchorWidth - popupWidth) / 2;
        int y = anchorY + (anchorHeight - popupHeight);

        popupWindow.showAtLocation(anchorView, Gravity.NO_GRAVITY, x, y);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (stepSensor == null) {
            Toast.makeText(this, "This device does not have a step sensor", Toast.LENGTH_SHORT).show();
        }


        else {
            mSensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            totalSteps = (int) event.values[0];
            int currentSteps = totalSteps - previousTotalSteps;
            steps.setText(String.valueOf(currentSteps));
            progressBar.setProgress(currentSteps);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used in this implementation
    }

    private void resetSteps() {
        steps.setOnClickListener(v -> {
            previousTotalSteps = totalSteps;
            steps.setText("0");
            progressBar.setProgress(0);
            saveData();
            Toast.makeText(homeScreen.this, "Steps reset", Toast.LENGTH_SHORT).show();
        });
    }

    private void saveData() {
        SharedPreferences sharedPreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("key1", String.valueOf(previousTotalSteps));
        editor.apply(); // Use apply() instead of commit() for asynchronous saving
    }

    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);
        String savedNumber = sharedPreferences.getString("key1", "0");
        previousTotalSteps = Integer.parseInt(savedNumber);
    }
}


//private void setupClickListeners() {
//    View stepsText;
//    stepsText.setOnClickListener(v -> {
//            previousTotalSteps = totalSteps;
//            updateStepDisplay(0);
//            caloriesBurned = 0;
//            updateCalorieDisplay();
//            saveUserData();
//            Toast.makeText(this, "Steps reset", Toast.LENGTH_SHORT).show();
//        });
//
//    View calorieText = null;
//    calorieText.setOnClickListener(v -> {
//            caloriesBurned = 0;
//            updateCalorieDisplay();
//            saveUserData();
//            Toast.makeText(this, "Calories reset", Toast.LENGTH_SHORT).show();
//        });


//    private void calculateCalories(int steps) {
//        // Calculate distance in kilometers
//        float distanceKm = (steps * strideLength) / 1000;
//
//        // Calories = MET * weight (kg) * time (hours)
//        // Assuming 5 km/h walking speed
//        float hours = distanceKm / 5f;
//        caloriesBurned = MET_VALUE * userWeight * hours;
//
//        updateCalorieDisplay();
//    }
//
//    private void updateStepDisplay(int currentSteps) {
//        stepsText.setText(String.format("Goal: 1000\nSteps: %d", currentSteps));
//        progressBar.setProgress(currentSteps);
//    }
//
//    private void updateCalorieDisplay() {
//        calorieText.setText(String.format("Goal: 500 cal\nBurned: %.1f cal", caloriesBurned));
//        calorieBar.setProgress((int) caloriesBurned);
//    }
//
//    @Override
//    public void onSensorChanged(SensorEvent event) {
//        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
//            totalSteps = (int) event.values[0];
//            int currentSteps = totalSteps - previousTotalSteps;
//
//            updateStepDisplay(currentSteps);
//            calculateCalories(currentSteps);
//        }
//    }
//
//    @Override
//    public void onAccuracyChanged(Sensor sensor, int accuracy) {
//        // Not needed but required by interface
//    }
//
//    private void saveUserData() {
//        SharedPreferences sharedPreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//        editor.putInt("previousSteps", previousTotalSteps);
//        editor.putFloat("caloriesBurned", caloriesBurned);
//        editor.putFloat("userWeight", userWeight);
//        editor.putFloat("strideLength", strideLength);
//        editor.apply();
//    }
//
//    private void loadUserData() {
//        SharedPreferences sharedPreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);
//        previousTotalSteps = sharedPreferences.getInt("previousSteps", 0);
//        caloriesBurned = sharedPreferences.getFloat("caloriesBurned", 0);
//        userWeight = sharedPreferences.getFloat("userWeight", 70f);
//        strideLength = sharedPreferences.getFloat("strideLength", 0.762f);
//
//        int currentSteps = totalSteps - previousTotalSteps;
//        updateStepDisplay(currentSteps);
//        updateCalorieDisplay();
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        if (stepSensor != null) {
//            mSensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL);
//        }
//    }
//
//    @Override
//    protected void onPause() {
//        super.onPause();
//        if (stepSensor != null) {
//            mSensorManager.unregisterListener(this);
//        }
//        saveUserData();
//    }
