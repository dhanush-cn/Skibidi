package com.example.mentree;

import android.app.*;
import android.content.*;
import android.os.*;
import androidx.core.app.NotificationCompat;
import java.util.*;

public class PositiveQuoteNotificationService extends IntentService {

    public PositiveQuoteNotificationService() {
        super("PositiveQuoteNotificationService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            sendNotification(getRandomPositiveQuote());
        }
    }

    private String getRandomPositiveQuote() {
        // Add your collection of positive quotes here
        List<String> quotes = new ArrayList<>();
        quotes.add("The only way to do great work is to love what you do. - Steve Jobs");
        quotes.add("Believe you can and you're halfway there. - Theodore Roosevelt");
        quotes.add("The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt");
        quotes.add("The only way to achieve the impossible is to believe it is possible. - Charles Kingsleigh");
        quotes.add("You are never too old to set another goal or to dream a new dream. - C.S. Lewis");
        quotes.add("Success is not the key to happiness. Happiness is the key to success. If you love what you are doing, you will be successful. - Albert Schweitzer");
        quotes.add("The only place where success comes before work is in the dictionary. - Vidal Sassoon");
        quotes.add("Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle. - Christian D. Larson");
        quotes.add("You are braver than you believe, stronger than you seem, and smarter than you think. - A.A. Milne");
        quotes.add("Life is 10% what happens to us and 90% how we react to it. - Charles R. Swindoll");
        quotes.add("Happiness is not something ready-made. It comes from your own actions. - Dalai Lama");
        quotes.add("The only person you should try to be better than is the person you were yesterday. - Anonymous");
        quotes.add("You miss 100% of the shots you don't take. - Wayne Gretzky");
        quotes.add("The best time to plant a tree was 20 years ago. The second best time is now. - Chinese Proverb");
        quotes.add("Your limitation—it's only your imagination. - Unknown");
        quotes.add("Push yourself, because no one else is going to do it for you. - Unknown");
        quotes.add("Great things never come from comfort zones. - Unknown");
        quotes.add("Dream it. Wish it. Do it. - Unknown");
        quotes.add("The harder you work for something, the greater you'll feel when you achieve it. - Unknown");
        quotes.add("The only way to do great work is to love what you do. - Steve Jobs");
        quotes.add("It always seems impossible until it is done. - Nelson Mandela");
        quotes.add("Success is not the key to happiness. Happiness is the key to success. If you love what you are doing, you will be successful. - Albert Schweitzer");
        quotes.add("The only limit to our realization of tomorrow will be our doubts of today. - Franklin D. Roosevelt");
        quotes.add("You don't have to be great to start, but you have to start to be great. - Zig Ziglar");
        quotes.add("Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill");
        quotes.add("Believe you can and you're halfway there. - Theodore Roosevelt");
        quotes.add("The only person you should try to be better than is the person you were yesterday. - Anonymous");
        quotes.add("Be not afraid of life. Believe that life is worth living, and your belief will help create the fact. - William James");
        quotes.add("If you want to lift yourself up, lift up someone else. - Booker T. Washington");
        quotes.add("What you get by achieving your goals is not as important as what you become by achieving your goals. - Zig Ziglar");
        quotes.add("The best way to predict the future is to invent it. - Alan Kay");
        quotes.add("Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle. - Christian D. Larson");
// Add more quotes here...

// Add more quotes here...

        // Get a random quote
        Random random = new Random();
        int index = random.nextInt(quotes.size());
        return quotes.get(index);
    }

    private void sendNotification(String quote) {
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Create a notification channel for devices running Android Oreo and higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("PositiveQuoteChannel",
                    "Positive Quote Channel", NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "PositiveQuoteChannel")
                .setContentTitle("Daily Positive Quote")
                .setContentText(quote)
                .setSmallIcon(R.drawable.notification);

        // Show the notification
        notificationManager.notify(0, builder.build());
    }
}
